package com.accenture.apa.listado.usuarios.portlet.constants;

/**
 * @author maria.luque.lopez
 */
public class UsuariosKeys {

	public static final String USUARIOS =
		"LISTA_USUARIOS";

}